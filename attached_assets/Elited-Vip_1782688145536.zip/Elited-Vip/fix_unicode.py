import re, os

with open('templates/app.html','rb') as f:
    raw = f.read()

# Decode bytes to str, replacing invalid stuff
text = raw.decode('utf-8', errors='replace')

def replace_unicode_escapes(s):
    # Find all \uXXXX sequences
    pattern = re.compile(r'\\u([0-9a-fA-F]{4})')
    result = []
    i = 0
    while i < len(s):
        m = pattern.match(s, i)
        if m:
            code = int(m.group(1), 16)
            # Check if this is a high surrogate (0xD800-0xDBFF)
            if 0xD800 <= code <= 0xDBFF:
                # Look ahead for low surrogate
                next_m = pattern.match(s, m.end())
                if next_m:
                    low = int(next_m.group(1), 16)
                    if 0xDC00 <= low <= 0xDFFF:
                        # Valid surrogate pair
                        full = 0x10000 + ((code - 0xD800) << 10) + (low - 0xDC00)
                        result.append(chr(full))
                        i = next_m.end()
                        continue
                # Not a valid surrogate pair, just output replacement char
                result.append('\ufffd')
                i = m.end()
                continue
            elif 0xDC00 <= code <= 0xDFFF:
                # Lone low surrogate, replacement char
                result.append('\ufffd')
                i = m.end()
                continue
            else:
                result.append(chr(code))
                i = m.end()
                continue
        result.append(s[i])
        i += 1
    return ''.join(result)

fixed = replace_unicode_escapes(text)

with open('templates/app.html', 'w', encoding='utf-8') as f:
    f.write(fixed)

print('Fixed app.html')

# Also fix admin.html
with open('templates/admin.html','rb') as f:
    raw2 = f.read()
text2 = raw2.decode('utf-8', errors='replace')
fixed2 = replace_unicode_escapes(text2)
with open('templates/admin.html', 'w', encoding='utf-8') as f:
    f.write(fixed2)

print('Fixed admin.html')
